java -Xmx2G -jar mzidentml-lib.jar MsgfPercolator example/input/msgfplusUps1.mzid example/output -decoyRegex "###REV###" -compress false
