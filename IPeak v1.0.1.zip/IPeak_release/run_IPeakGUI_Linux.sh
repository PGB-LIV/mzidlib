java -Xmx2G -cp mzidentml-lib.jar bgi.ipeak.gui.IPeakGui
